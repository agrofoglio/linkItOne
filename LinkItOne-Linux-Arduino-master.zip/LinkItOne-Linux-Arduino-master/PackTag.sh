#!/bin/sh
wine $(dirname $0)/PackTag.exe $1 $2
